<?php

namespace Database\Factories;

use App\Models\Customer;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Reservation>
 */
class ReservationFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'entry_date' => fake()->dateTimeBetween('-10 years', 'now')->format('Y-m-d'),
            'departure_date' => fake()->dateTimeBetween('-10 years', 'now')->format('Y-m-d'),
            'number_guests' => rand(1, 10),
            'travel_reason' => fake()->words(3, true),
            'total_price' => rand(100, 1000),
            'contracted_food' => fake()->words(3, true),
            'special_requests' => fake()->words(3, true),
            'reservation_channel'  => fake()->words(1, true),
            'customer_id' => Customer::inRandomOrder()->first()->id
        ];
    }
}
