<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Room;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Service>
 */
class ServiceFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'service' => fake()->word(2, true),
            'date' => fake()->dateTimeBetween('-10 years', 'now')->format('Y-m-d'),
            'hour' => fake()->time(),
            'total' => fake()->randomFloat(2, 10, 100),
            'payment_moment' => fake()->boolean(),
            'room_id' => Room::inRandomOrder()->first()->id,
        ];
    }
}
