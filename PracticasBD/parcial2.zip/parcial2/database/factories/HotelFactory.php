<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Hotel>
 */
class HotelFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'code' => fake()->words(3, true),
            'name' => fake()->company(),
            'stars' => rand(1, 5),
            'address' => fake()->address(),
            'phone' => fake()->phoneNumber(),
            'email' => fake()->unique()->safeEmail(),
            'inauguration_date'  => fake()->dateTimeBetween('-10 years', 'now')->format('Y-m-d'),
            'description' => fake()->text(100),
            'services'  => fake()->text(100),
            'policy_pets' => fake()->words(3, true)
        ];
    }
}
