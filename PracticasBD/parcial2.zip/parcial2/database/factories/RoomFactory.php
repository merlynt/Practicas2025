<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Hotel;
use App\Models\RoomType;
use App\Models\Reservation;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Room>
 */
class RoomFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'room_num' => fake()->unique()->numberBetween(1, 100),
            'location' => fake()->address(),
            'hotel_id' => Hotel::inRandomOrder()->first()->id,
            'room_type_id'=> RoomType::inRandomOrder()->first()->id,
            'reservation_id' => Reservation::inRandomOrder()->first()->id,
        ];
    }
}
