<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Price;
/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\RoomType>
 */
class RoomTypeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'code' => fake()->unique()->word(1, true),
            'type' => fake()->word(1, true),
            'max_capacity' => rand(1, 5),
            'availabel_quantity' => rand(1, 10),
            'flat' => rand(1, 10),
            'orientation' => fake()->word(3, true),
            'maintenance' => fake()->word(3, true),
            'price_id' => Price::inRandomOrder()->first()->id
        ];
    }
}
