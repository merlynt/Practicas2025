<?php

namespace Database\Factories;

use App\Models\Reservation;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Deposit>
 */
class DepositFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'payment_method' => $this->faker->randomElement(['credit_card', 'cash']),
            'deposited_money' => rand(100, 1000),
            'money_returned' => rand(0, 100),
            'reservation_id' => Reservation::inRandomOrder()->first()->id
        ];
    }
}
