<?php

namespace Database\Factories;

use App\Models\Hotel;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Employee>
 */
class EmployeeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'department' => fake()->company(),
            'code' => fake()->unique()->word(1, true),
            'name' => fake()->name(),
            'position' => fake()->word(1, true),
            'shif' => fake()->word(1, true),
            'hiring_date' => fake()->dateTimeBetween('-10 years', 'now')->format('Y-m-d'),
            'contact_data' => fake()->text(100),
            'access_level' => fake()->word(1, true),
            'hotel_id' => Hotel::inRandomOrder()->first()->id
        ];
    }
}
