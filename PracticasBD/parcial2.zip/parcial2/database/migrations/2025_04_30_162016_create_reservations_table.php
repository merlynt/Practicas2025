<?php

use App\Models\Customer;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('reservations', function (Blueprint $table) {
            $table->id();
            $table->date('entry_date');
            $table->date('departure_date');
            $table->integer('number_guests');
            $table->string('travel_reason', 75);
            $table->decimal('total_price', 10, 2);
            $table->string('contracted_food', 100);
            $table->text('special_requests')->nullable();
            $table->string('reservation_channel', 45);
            $table->foreignIdFor(Customer::class)->constrained();
            $table->timestamps();
        });
    }
    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('reservations');
    }
};
