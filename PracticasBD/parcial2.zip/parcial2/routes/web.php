<?php

use App\Models\Reservation;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ReservationController;
use App\Http\Controllers\EmployeeController;
use App\Models\Employee;

Route::get('/', function () {
    return view('welcome');


});

Route::resource('resevations', ReservationController::class);
Route::resource('employees', EmployeeController::class);
