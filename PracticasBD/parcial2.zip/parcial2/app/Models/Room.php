<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\Service;

class Room extends Model
{
    /** @use HasFactory<\Database\Factories\RoomFactory> */
    use HasFactory;

    protected $fillable = [
        'room_num',
        'location',
        'hotel_id',
        'room_type_id',
        'reservation_id',
    ];

    public function services():HasMany
    {
        return $this->hasMany(Service::class);
    }

    public function hotel():BelongsTo
    {
        return $this->belongsTo(Hotel::class);
    }
    public function roomType():BelongsTo
    {
        return $this->belongsTo(RoomType::class);
    }
    public function reservation():BelongsTo
    {
        return $this->belongsTo(Reservation::class);
    }
}
