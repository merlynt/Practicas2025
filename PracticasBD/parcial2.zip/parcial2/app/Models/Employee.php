<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Employee extends Model
{
    /** @use HasFactory<\Database\Factories\EmployeeFactory> */
    use HasFactory;

    protected $fillable = [
        'department',
        'code',
        'name',
        'position',
        'shif',
        'hiring_date',
        'contact_data',
        'access_level',
        'hotel_id'
    ];

    public function hotel():BelongsTo
    {
        return $this->belongsTo(Hotel::class);
    }
}
