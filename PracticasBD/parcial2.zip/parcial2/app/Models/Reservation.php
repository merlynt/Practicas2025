<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\Room;

class Reservation extends Model
{
    /** @use HasFactory<\Database\Factories\ReservationFactory> */
    use HasFactory;

    protected $fillable = [
        'entry_date',
        'departure_date',
        'number_guests',
        'travel_reason',
        'total_price',
        'contracted_food',
        'special_requests',
        'reservation_channel',
        'customer_id'
    ];

    public function customer():BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function rooms():HasMany
    {
        return $this->hasMany(Room::class);
    }
}
