<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\RoomType;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Price extends Model
{
    /** @use HasFactory<\Database\Factories\PriceFactory> */
    use HasFactory;

    protected $fillable = [
        'base_price',
        'season',
    ];

    public function roomTypes():HasMany
    {
        return $this->hasMany(RoomType::class);
    }
}
