<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Employee;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Hotel extends Model
{
    /** @use HasFactory<\Database\Factories\HotelFactory> */
    use HasFactory;

    protected $fillable = [
        'code',
        'name',
        'stars',
        'address',
        'phone',
        'email',
        'inauguration_date',
        'description',
        'services',
        'policy_pets'
    ];

    public function employees():HasMany
    {
        return $this->hasMany(Employee::class);
    }

    public function rooms():HasMany
    {
        return $this->hasMany(Room::class);
    }


}
