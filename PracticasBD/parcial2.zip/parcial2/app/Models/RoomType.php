<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\Room;

class RoomType extends Model
{
    /** @use HasFactory<\Database\Factories\RoomTypeFactory> */
    use HasFactory;
    protected $fillable = [
        'code',
        'type',
        'max_capacity',
        'availabel_quantity',
        'flat',
        'orientation',
        'maintenance',
        'price_id'
    ];

    public function price():BelongsTo
    {
        return $this->belongsTo(Price::class);
    }

    public function rooms():HasMany
    {
        return $this->hasMany(Room::class);
    }
}
