<div>
<!DOCTYPE html>
<html lang="en" class="dark">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empleados</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-100 text-gray-900">

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-950">

                    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-900">
                            <thead class="text-xs text-gray-900 uppercase bg-gray-500 dark:bg-gray-700 dark:text-gray-900">
                                <tr>
                                    <th scope="col" class="px-6 py-3">Empleado</th>
                                    <th scope="col" class="px-6 py-3">Departamento</th>
                                    <th scope="col" class="px-6 py-3">Hotel</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd:bg-white even:bg-gray-500 border-b dark:border-gray-900">
                                    <td class="px-6 py-4"><?php echo e($employee->name); ?></td>
                                    <td class="px-6 py-4"><?php echo e($employee->department); ?></td>
                                    <td class="px-6 py-4"><?php echo e($employee->hotel->name); ?></td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

</body>

</html>
<?php /**PATH C:\Users\merly\Herd\parcial2\resources\views/employees/index.blade.php ENDPATH**/ ?>